Set ServerOutput On;
CREATE OR REPLACE TRIGGER bb_salessum_trg
AFTER UPDATE OF orderplaced ON bb_basket
FOR EACH ROW
WHEN(OLD.orderplaced <> 1 AND NEW.orderplaced = 1)
DECLARE
CURSOR basketitem_cur IS
  select idproduct, price, quantity 
  from bb_basketitem 
  where idbasket = :New.idbasket;
   lv_count number;
BEGIN
	for rec in basketitem_cur
	LOOP
		select count(*)
		into lv_count
		from bb_sales_sum
		where product_id = rec.idproduct;
		
		if lv_count > 0 then
			UPDATE bb_sales_sum
			SET total_qty = total_qty + rec.quantity,
			total_sales = total_sales + (rec.quantity * rec.price)
			WHERE product_id = rec.idproduct;
		else
			insert into bb_sales_sum
			values(rec.idproduct, rec.price, rec.quantity);
		end if;
	END LOOP;
END;
/

 