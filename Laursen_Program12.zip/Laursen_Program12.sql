--/***************************************************************/
--  Developer:            Julie Laursen
--
--  Program #:            12
--
--  File Name:            Program 12.sql
--
--  Course:               ITSE 1345 Introduction to Oracle SQL and PL/SQL
--
--  Due Date:             5/11
--
--  Instructor:           Fred Kumi 
--
--  Chapter:              10
--
--  Description:
--     Dynamically query based on product name or description
--

Set ServerOutput On;

CREATE OR REPLACE PACKAGE SEARCH_PKG
AS
TYPE refcur_type IS REF CURSOR;
PROCEDURE search_sp 
(p_col IN VARCHAR2,
p_value IN VARCHAR2,
p_cursor IN OUT refcur_type);
END;
/
CREATE OR REPLACE PACKAGE BODY SEARCH_PKG
AS PROCEDURE search_sp
(p_col IN VARCHAR2,
p_value IN VARCHAR2,
p_cursor IN OUT refcur_type
)
IS
  lv_query VARCHAR2(200);
  lv_bind VARCHAR2(20);
  
 BEGIN   
lv_query := 'SELECT idproduct, productname, description
            FROM bb_product
            WHERE UPPER(' ||p_col|| ') LIKE UPPER(:p_value)';
lv_bind := '%' || p_value || '%';
OPEN p_cursor FOR lv_query USING lv_bind;

END;			
END;
/
