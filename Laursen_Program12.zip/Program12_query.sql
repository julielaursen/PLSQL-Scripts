var r refcursor;
/
BEGIN
   SEARCH_PKG.search_sp('productname', 'espresso',:r); 
END;
/
print r