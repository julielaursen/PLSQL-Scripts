--/***************************************************************/
--  Developer:            Julie Laursen
--
--  Program #:            7
--
--  File Name:            Program 7.sql
--
--  Course:               ITSE 1345 Introduction to Oracle SQL and PL/SQL
--
--  Due Date:             3/26
--
--  Instructor:           Fred Kumi 
--
--  Chapter:              
--
--  Description:
--     Create a cursor that displays an asterik in a column stock flag if the stock value is $75 or over, null if under $75
--
set Serveroutput On;


 ALTER TABLE MM_MOVIE ADD STK_FLAG varchar(1);
 
    DECLARE
	exception_1 EXCEPTION;
    
	CURSOR cur_1 is 
		SELECT movie_id from MM_MOVIE where movie_qty*movie_value >= 75;

	BEGIN
		for movieid in cur_1 loop
			update MM_MOVIE
			set STK_FLAG = '*'
			where MOVIE_ID = movieid.MOVIE_ID;
		end loop;
	
	--close cur_1;
	
	EXCEPTION
		WHEN exception_1 THEN dbms_output.put_line('A problem has occured. Tech Support will be notified.');	
		
 END;
 /
 
 